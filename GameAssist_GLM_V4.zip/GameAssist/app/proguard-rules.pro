# GameAssist ProGuard Rules
-keepattributes *Annotation*
-keep class com.gameassist.models.** { *; }
-keep class com.gameassist.GameAssistService { *; }
-keep class com.gameassist.MainActivity { *; }

# Keep coroutine suspend functions
-keepclassmembers class kotlinx.coroutines.** { *; }

# Keep AccessibilityService
-keep class android.accessibilityservice.** { *; }
